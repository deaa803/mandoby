<?php

namespace App\Http\Controllers;

use App\Models\Advertisement;
use App\Models\Category;
use App\Models\ProductDetail;
use Carbon\Carbon;
use App\Models\Company;

class HomeController extends Controller
{
    private array $productDetailRelations = [
        'product',
        'category',
        'company',
        'images',
        'features',
        'model3d',
    ];

    public function categories()
    {
        $categories = Category::latest()->get();

        return response()->json([
            'status' => true,
            'message' => 'Categories retrieved successfully',
            'data' => $categories,
        ]);
    }

    public function specialProducts()
    {
        $specialProducts = ProductDetail::with($this->productDetailRelations)
            ->latest()
            ->take(10)
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Special products retrieved successfully',
            'data' => $specialProducts,
        ]);
    }

    public function offers()
    {
        $now = Carbon::now();

        $offers = Advertisement::with([
            'company',
            'productDetail.product',
            'productDetail.category',
            'productDetail.images',
            'productDetail.features',
            'productDetail.model3d',
        ])
            ->where('status', 'active')
            ->where(function ($query) use ($now) {
                $query->whereNull('starts_at')
                    ->orWhere('starts_at', '<=', $now);
            })
            ->where(function ($query) use ($now) {
                $query->whereNull('ends_at')
                    ->orWhere('ends_at', '>=', $now);
            })
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Offers retrieved successfully',
            'data' => $offers,
        ]);
    }

    public function productsByCategory($id)
    {
        $products = ProductDetail::with($this->productDetailRelations)
            ->where('category_id', $id)
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Products retrieved successfully',
            'data' => $products,
        ]);
    }

    public function productsByCompany($id)
    {
        $products = ProductDetail::with($this->productDetailRelations)
            ->where('company_id', $id)
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Products retrieved successfully',
            'data' => $products,
        ]);
    }

    public function homepage()
    {
        $now = Carbon::now();
        $companies = Company::latest()->get();
        $categories = Category::latest()->get();

        $specialProducts = ProductDetail::with($this->productDetailRelations)
            ->where('status', 'available')
            ->latest()
            ->take(10)
            ->get();

        $offers = Advertisement::with([
            'company',
            'productDetail.product',
            'productDetail.category',
            'productDetail.images',
            'productDetail.features',
            'productDetail.model3d',
        ])
            ->where('status', 'active')
            ->where(function ($query) use ($now) {
                $query->whereNull('starts_at')
                    ->orWhere('starts_at', '<=', $now);
            })
            ->where(function ($query) use ($now) {
                $query->whereNull('ends_at')
                    ->orWhere('ends_at', '>=', $now);
            })
            ->latest()
            ->take(10)
            ->get();

        return response()->json([
            'status' => true,
            'message' => 'Home data retrieved successfully',
            'data' => [
                'companies' => $companies,
                'categories' => $categories,
                'special_products' => $specialProducts,
                'offers' => $offers,
            ],
        ]);
    }
}
