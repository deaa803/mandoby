<?php

namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class DashboardControls extends Widget
{
    protected static string $view = 'filament.widgets.dashboard-controls';

    protected int|string|array $columnSpan = 'full';

    protected static ?int $sort = -100;
}
