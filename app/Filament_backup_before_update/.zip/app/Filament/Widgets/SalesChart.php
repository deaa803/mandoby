<?php

namespace App\Filament\Widgets;

use App\Models\Order;
use App\Models\Product;
use Carbon\Carbon;
use Filament\Widgets\ChartWidget;
use Illuminate\Support\Facades\DB;

class SalesChart extends ChartWidget
{
    protected static ?int $sort = 2;

    protected int|string|array $columnSpan = ['md' => 2, 'xl' => 2];

    public function getHeading(): string
    {
        return request()->cookie('admin_locale', 'ar') === 'en'
            ? 'Platform activity — last 30 days'
            : 'نشاط المنصة — آخر 30 يومًا';
    }

    protected function getData(): array
    {
        $isArabic = request()->cookie('admin_locale', 'ar') !== 'en';
        $dates = collect(range(29, 0))
            ->map(fn (int $days) => Carbon::today()->subDays($days)->format('Y-m-d'));

        $ordersData = Order::query()
            ->selectRaw('DATE(created_at) AS day, COUNT(*) AS total')
            ->where('status', '!=', 'cancelled')
            ->whereIn(DB::raw('DATE(created_at)'), $dates->all())
            ->groupBy('day')
            ->pluck('total', 'day');

        $productsData = Product::query()
            ->selectRaw('DATE(created_at) AS day, COUNT(*) AS total')
            ->whereIn(DB::raw('DATE(created_at)'), $dates->all())
            ->groupBy('day')
            ->pluck('total', 'day');

        $profitData = Order::query()
            ->selectRaw('DATE(created_at) AS day, SUM(commission) AS total')
            ->where('status', '!=', 'cancelled')
            ->whereIn(DB::raw('DATE(created_at)'), $dates->all())
            ->groupBy('day')
            ->pluck('total', 'day');

        return [
            'datasets' => [
                [
                    'label' => $isArabic ? 'الطلبات' : 'Orders',
                    'data' => $dates->map(fn (string $date) => (int) ($ordersData[$date] ?? 0))->all(),
                    'borderColor' => '#2f80ed',
                    'backgroundColor' => 'rgba(47, 128, 237, .14)',
                    'tension' => .42,
                    'fill' => true,
                    'pointRadius' => 0,
                    'borderWidth' => 3,
                ],
                [
                    'label' => $isArabic ? 'المنتجات الجديدة' : 'New products',
                    'data' => $dates->map(fn (string $date) => (int) ($productsData[$date] ?? 0))->all(),
                    'borderColor' => '#27ae60',
                    'backgroundColor' => 'rgba(39, 174, 96, .12)',
                    'tension' => .42,
                    'fill' => true,
                    'pointRadius' => 0,
                    'borderWidth' => 3,
                ],
                [
                    'label' => $isArabic ? 'أرباح المنصة' : 'Platform profit',
                    'data' => $dates->map(fn (string $date) => round((float) ($profitData[$date] ?? 0), 2))->all(),
                    'borderColor' => '#d6aa28',
                    'backgroundColor' => 'rgba(214, 170, 40, .12)',
                    'tension' => .42,
                    'fill' => true,
                    'pointRadius' => 0,
                    'borderWidth' => 3,
                ],
            ],
            'labels' => $dates->map(fn (string $date) => Carbon::parse($date)->format('d M'))->all(),
        ];
    }

    protected function getType(): string
    {
        return 'line';
    }
}
