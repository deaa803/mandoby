<?php

namespace App\Filament\Widgets;

use App\Models\Company;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

class CompanyProfits extends TableWidget
{
    protected static ?int $sort = 3;

    protected int|string|array $columnSpan = 'full';

    public function getHeading(): string
    {
        return request()->cookie('admin_locale', 'ar') === 'en'
            ? 'Platform profit by company'
            : 'أرباح المنصة من كل شركة';
    }

    public function table(Table $table): Table
    {
        $isArabic = request()->cookie('admin_locale', 'ar') !== 'en';

        return $table
            ->query($this->companyQuery())
            ->defaultSort('platform_profit', 'desc')
            ->paginated([5, 10, 25])
            ->columns([
                ImageColumn::make('logo')
                    ->label($isArabic ? 'الشعار' : 'Logo')
                    ->disk('public')
                    ->circular()
                    ->defaultImageUrl(fn (Company $record) => 'https://ui-avatars.com/api/?name=' . urlencode($record->name_company)),

                TextColumn::make('name_company')
                    ->label($isArabic ? 'الشركة' : 'Company')
                    ->searchable()
                    ->sortable()
                    ->weight('bold'),

                TextColumn::make('orders_count')
                    ->label($isArabic ? 'الطلبات' : 'Orders')
                    ->numeric()
                    ->sortable()
                    ->badge()
                    ->color('info'),

                TextColumn::make('gross_sales')
                    ->label($isArabic ? 'مبيعات الشركة' : 'Company sales')
                    ->formatStateUsing(fn ($state) => number_format((float) $state, 2) . ' SYP')
                    ->sortable(),

                TextColumn::make('platform_profit')
                    ->label($isArabic ? 'ربح المنصة' : 'Platform profit')
                    ->formatStateUsing(fn ($state) => number_format((float) $state, 2) . ' SYP')
                    ->sortable()
                    ->weight('bold')
                    ->color('warning'),

                TextColumn::make('average_commission')
                    ->label($isArabic ? 'متوسط العمولة' : 'Average commission')
                    ->formatStateUsing(fn ($state) => number_format((float) $state, 2) . ' SYP')
                    ->toggleable(),
            ]);
    }

    private function companyQuery(): Builder
    {
        $orderCompany = DB::table('order_product_detail as opd')
            ->join('product_details as pd', 'pd.id', '=', 'opd.product_detail_id')
            ->selectRaw('opd.order_id, MIN(pd.company_id) AS company_id')
            ->groupBy('opd.order_id');

        $aggregates = DB::query()
            ->fromSub($orderCompany, 'oc')
            ->join('orders as o', 'o.id', '=', 'oc.order_id')
            ->where('o.status', '!=', 'cancelled')
            ->selectRaw('oc.company_id')
            ->selectRaw('COUNT(o.id) AS orders_count')
            ->selectRaw('COALESCE(SUM(o.total_price), 0) AS gross_sales')
            ->selectRaw('COALESCE(SUM(o.commission), 0) AS platform_profit')
            ->selectRaw('COALESCE(AVG(o.commission), 0) AS average_commission')
            ->groupBy('oc.company_id');

        return Company::query()
            ->leftJoinSub($aggregates, 'company_finance', function ($join): void {
                $join->on('companies.id', '=', 'company_finance.company_id');
            })
            ->select('companies.*')
            ->selectRaw('COALESCE(company_finance.orders_count, 0) AS orders_count')
            ->selectRaw('COALESCE(company_finance.gross_sales, 0) AS gross_sales')
            ->selectRaw('COALESCE(company_finance.platform_profit, 0) AS platform_profit')
            ->selectRaw('COALESCE(company_finance.average_commission, 0) AS average_commission');
    }
}
