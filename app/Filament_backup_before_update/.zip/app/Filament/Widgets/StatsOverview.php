<?php

namespace App\Filament\Widgets;

use App\Models\Company;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product3DModel;
use App\Models\Store;
use Carbon\Carbon;
use Filament\Widgets\StatsOverviewWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverview extends StatsOverviewWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        $locale = request()->cookie('admin_locale', 'ar');
        $isArabic = $locale !== 'en';

        $orders = Order::query()->where('status', '!=', 'cancelled');
        $totalRevenue = (float) (clone $orders)->sum('total_price');
        $totalPayments = (float) Payment::query()->sum('amount');
        $appProfit = (float) (clone $orders)->sum('commission');
        $pendingOrders = Order::query()->whereIn('status', ['pending', 'preparing'])->count();

        return [
            Stat::make($isArabic ? 'الشركات المسجلة' : 'Registered companies', Company::count())
                ->description($isArabic ? 'إجمالي الشركات على المنصة' : 'Total companies on the platform')
                ->descriptionIcon('heroicon-m-building-office-2')
                ->chart($this->dailyCountTrend(Company::class))
                ->color('warning')
                ->extraAttributes(['class' => 'dashboard-stat dashboard-stat--gold']),

            Stat::make($isArabic ? 'المتاجر المسجلة' : 'Registered stores', Store::count())
                ->description($isArabic ? 'إجمالي المتاجر النشطة' : 'Total active stores')
                ->descriptionIcon('heroicon-m-building-storefront')
                ->chart($this->dailyCountTrend(Store::class))
                ->color('success')
                ->extraAttributes(['class' => 'dashboard-stat dashboard-stat--green']),

            Stat::make($isArabic ? 'إجمالي الطلبات' : 'Total orders', Order::count())
                ->description(($isArabic ? 'قيد التنفيذ: ' : 'In progress: ') . number_format($pendingOrders))
                ->descriptionIcon('heroicon-m-shopping-bag')
                ->chart($this->orderTrend())
                ->color('info')
                ->extraAttributes(['class' => 'dashboard-stat dashboard-stat--blue']),

            Stat::make($isArabic ? 'إجمالي المبيعات' : 'Gross sales', number_format($totalRevenue, 2) . ' SYP')
                ->description($isArabic ? 'باستثناء الطلبات الملغاة' : 'Excluding cancelled orders')
                ->descriptionIcon('heroicon-m-banknotes')
                ->chart($this->revenueTrend())
                ->color('success')
                ->extraAttributes(['class' => 'dashboard-stat dashboard-stat--emerald']),

            Stat::make($isArabic ? 'أرباح المنصة' : 'Platform profit', number_format($appProfit, 2) . ' SYP')
                ->description($isArabic ? 'مجموع عمولات الشركات' : 'Total company commissions')
                ->descriptionIcon('heroicon-m-arrow-trending-up')
                ->chart($this->profitTrend())
                ->color('warning')
                ->extraAttributes(['class' => 'dashboard-stat dashboard-stat--purple']),

            Stat::make($isArabic ? 'المدفوعات المحصلة' : 'Collected payments', number_format($totalPayments, 2) . ' SYP')
                ->description($isArabic ? 'إجمالي الدفعات المسجلة' : 'Total recorded payments')
                ->descriptionIcon('heroicon-m-credit-card')
                ->chart($this->paymentTrend())
                ->color('info')
                ->extraAttributes(['class' => 'dashboard-stat dashboard-stat--orange']),

            Stat::make($isArabic ? 'موديلات 3D الجاهزة' : 'Ready 3D models', Product3DModel::query()->where('status', 'completed')->count())
                ->description($isArabic ? 'نماذج مكتملة وقابلة للعرض' : 'Completed and viewable models')
                ->descriptionIcon('heroicon-m-cube-transparent')
                ->color('success')
                ->extraAttributes(['class' => 'dashboard-stat dashboard-stat--cyan']),
        ];
    }

    private function dateRange(): array
    {
        return collect(range(6, 0))
            ->map(fn (int $days) => Carbon::today()->subDays($days)->format('Y-m-d'))
            ->all();
    }

    private function dailyCountTrend(string $model): array
    {
        $dates = $this->dateRange();
        $data = $model::query()
            ->selectRaw('DATE(created_at) AS day, COUNT(*) AS total')
            ->whereDate('created_at', '>=', Carbon::today()->subDays(6))
            ->groupBy('day')
            ->pluck('total', 'day');

        return collect($dates)->map(fn (string $date) => (int) ($data[$date] ?? 0))->all();
    }

    private function orderTrend(): array
    {
        return $this->aggregateOrderTrend('COUNT(*)');
    }

    private function revenueTrend(): array
    {
        return $this->aggregateOrderTrend('SUM(total_price)');
    }

    private function profitTrend(): array
    {
        return $this->aggregateOrderTrend('SUM(commission)');
    }

    private function aggregateOrderTrend(string $expression): array
    {
        $dates = $this->dateRange();
        $data = Order::query()
            ->selectRaw("DATE(created_at) AS day, {$expression} AS total")
            ->where('status', '!=', 'cancelled')
            ->whereDate('created_at', '>=', Carbon::today()->subDays(6))
            ->groupBy('day')
            ->pluck('total', 'day');

        return collect($dates)->map(fn (string $date) => (float) ($data[$date] ?? 0))->all();
    }

    private function paymentTrend(): array
    {
        $dates = $this->dateRange();
        $data = Payment::query()
            ->selectRaw('DATE(created_at) AS day, SUM(amount) AS total')
            ->whereDate('created_at', '>=', Carbon::today()->subDays(6))
            ->groupBy('day')
            ->pluck('total', 'day');

        return collect($dates)->map(fn (string $date) => (float) ($data[$date] ?? 0))->all();
    }
}
