<?php

namespace App\Filament\Resources\Companies\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ViewAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Support\Facades\DB;

class CompaniesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                ImageColumn::make('logo')
                    ->disk('public')
                    ->label('الشعار')
                    ->circular(),

                TextColumn::make('name_company')
                    ->label('اسم الشركة')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('user.name')
                    ->label('المالك')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('product_details_count')
                    ->counts('productDetails')
                    ->label('المنتجات'),

                TextColumn::make('drivers_count')
                    ->counts('drivers')
                    ->label('السائقين'),

                TextColumn::make('stores_count')
                    ->counts('stores')
                    ->label('المتاجر'),

                TextColumn::make('delivery_radius_km')
                    ->suffix(' كم')
                    ->label('حد التوصيل'),

                TextColumn::make('extra_delivery_fee_per_km')
                    ->money('SYP')
                    ->label('أجرة الكيلو الزائد')
                    ->toggleable(),

                TextColumn::make('platform_orders_count')
                    ->label('طلبات الشركة')
                    ->state(fn ($record): int => self::companyFinancials($record->id)['orders_count'])
                    ->numeric()
                    ->badge()
                    ->color('info'),

                TextColumn::make('platform_profit')
                    ->label('ربح المنصة من الشركة')
                    ->state(fn ($record): string => number_format(self::companyFinancials($record->id)['platform_profit'], 2) . ' SYP')
                    ->color('warning')
                    ->weight('bold'),

                TextColumn::make('currentSubscription.plan.name')
                    ->label('الاشتراك')
                    ->placeholder('-'),

                TextColumn::make('currentSubscription.end_date')
                    ->dateTime()
                    ->label('ينتهي في')
                    ->placeholder('-'),

                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true)
                    ->label('تاريخ الإنشاء'),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                ViewAction::make(),
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    private static function companyFinancials(int $companyId): array
    {
        $row = DB::table('orders as o')
            ->join('order_product_detail as opd', 'opd.order_id', '=', 'o.id')
            ->join('product_details as pd', 'pd.id', '=', 'opd.product_detail_id')
            ->where('pd.company_id', $companyId)
            ->where('o.status', '!=', 'cancelled')
            ->selectRaw('COUNT(DISTINCT o.id) AS orders_count, COALESCE(SUM(DISTINCT o.commission), 0) AS platform_profit')
            ->first();

        return [
            'orders_count' => (int) ($row->orders_count ?? 0),
            'platform_profit' => (float) ($row->platform_profit ?? 0),
        ];
    }
}
