<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('company_cars', function (Blueprint $table) {
            $table->id();

            $table->foreignId('company_id')
                ->constrained('companies')
                ->cascadeOnDelete();

            $table->string('vehicle_type');
            $table->string('driver_name');
            $table->string('plate_number');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('company_cars');
    }
};
